
<?php $__env->startSection('content'); ?>
    <div class="m-4"></div>
    <h4 class="m-4">Admin page</h4>
    <table class="table table-striped m-4 table table-bordered " >
        <thead>
            <tr>
                <th scope="col"></th>
                <th scope="col">Id</th>
                <th scope="col">Name</th>
                <th scope="col">Email</th>
                <th scope="col">Phone</th>
                <th scope="col">Comments</th>
                <th scope="col">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"></th>
                    <td><?php echo e($member['id']); ?></td>
                    <td><?php echo e($member['name']); ?></td>
                    <td><?php echo e($member['email']); ?></td>
                    <td><?php echo e($member['phone']); ?></td>
                    <td><?php echo e(substr($member['queries'], 0, 150)); ?></td>
                    <td><a href='delete/<?php echo e($member->id); ?>' onclick="return confirm('Are you want to delete?')"><img src="images/delete.png" alt="" height="22px"
                                width="22px"></a></td>
                    <td><a href='edit/<?php echo e($member->id); ?>' data-bs-toggle="modal" data-bs-target="#myModal"><img
                                src="images/edit.png" alt="" height="22px"></a></td>
                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>
    </div>

    <div class="modal" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Update Information</h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>

                </div>
                <form method="post" action="<?php echo e(url('update')); ?> ">
                    <?php echo csrf_field(); ?>
                    

                    <input type="hidden" class="form-control input-sm"   value="<?php echo e($member['id']); ?>"name="id">


                    <div class="modal-body">
                        <label>Name</label>
                        
                        <input type="text" class="form-control input-sm" value="<?php echo e($member['name']); ?>"  name="name">
                    </div>

                    <div class="modal-body">
                        <label>Email</label>
                        
                        <input type="email" class="form-control input-sm" value="<?php echo e($member['email']); ?>"  name="email">
                    </div>

                    <div class="modal-body">
                        <label>Phone</label>
                        
                        <input type="text" class="form-control input-sm" value="<?php echo e($member['phone']); ?>" name="phone">
                    </div>

                    <div class="modal-body">
                        <label>Comments/Queries</label>
                        
                        <textarea class="form-control" name="queries" rows="3"> <?php echo e($member['queries']); ?></textarea>
                    </div>
                    <!-- Modal footer -->
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary btn-sm" data-bs-dismiss="modal">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my-blog\resources\views/index.blade.php ENDPATH**/ ?>