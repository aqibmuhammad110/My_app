<!DOCTYPE html>
<link rel="stylesheet" href="css/mystyle.css">
<footer>
    <footer class="bg-dark text-center text-lg-start fixed-bottom ">
        <!-- Copyright -->
        <div class="text-center p-3 text-light" style="background-color: rgba(0, 0, 0, 0.2);">
            © 2023 Copyright:
            <a class="text-light">Rapid web development course 2023</a>
        </div>
        <!-- Copyright -->
    </footer>
</footer>
<?php /**PATH C:\xampp\htdocs\my-blog\resources\views/layouts/footer.blade.php ENDPATH**/ ?>