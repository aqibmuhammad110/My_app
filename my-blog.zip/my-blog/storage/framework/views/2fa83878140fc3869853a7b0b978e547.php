
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <form method="post" action="<?php echo e(url('contact')); ?> ">
                        <?php echo csrf_field(); ?>
                        <div class="p-3">
                            <h4>Update Users Details</h4>
                            <div class="mb-3 w-50">
                                <label>Name</label>
                                <input type="text" class="form-control" value=<?php echo e($data->name); ?> name="name">

                                
                            </div>
                            <div class="mb-3 w-50  ">
                                <label>Email</label>
                                <input type="email" class="form-control" value=<?php echo e($data->email); ?>  name="email">
                            </div>
                            <div class="mb-3 w-50">
                                <label>Phone</label>
                                <input type="text" class="form-control " value=<?php echo e($data->phone); ?> name="phone">
                            </div>

                            <div class="mb-3 w-50">
                                <label>Comments/Queries</label>
                                <textarea class="form-control" name="queries" value=<?php echo e($data->queries); ?> rows="3"></textarea>
                            </div class="mb-1">

                            <button type="submit" class="btn btn-primary btn-sm">Update</button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my-blog\resources\views/edit.blade.php ENDPATH**/ ?>