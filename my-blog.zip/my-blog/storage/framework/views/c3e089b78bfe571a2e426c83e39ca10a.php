
<?php $__env->startSection('content'); ?>
    <p>this is my services page</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my-blog\resources\views/services.blade.php ENDPATH**/ ?>