<?php echo $__env->yieldContent('content'); ?>
<header>
    <nav class="navbar navbar-expand-lg bg-dark text-light">
        <div class="container-fluid">
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link active  text-light" aria-current="page" href="index.php">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link  active text-light" href="certificates.php">Certificates</a>
              </li>
              <li class="nav-item">
                <a class="nav-link  active text-light" href="projects.php">Projects</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active   text-light">Contact Us</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
</header>

<?php /**PATH C:\xampp\htdocs\my-blog\resources\views/sections/header.blade.php ENDPATH**/ ?>