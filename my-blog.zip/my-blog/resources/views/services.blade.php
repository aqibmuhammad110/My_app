@extends('home')
@section('content')
    <p>this is my services page</p>
@endsection
