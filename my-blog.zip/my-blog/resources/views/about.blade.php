@extends('home')
@section('content')

    <p>this is my about page</p>
@endsection