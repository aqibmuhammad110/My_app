@include('layouts.header')
<body>
@yield('content')
   



</body>
@include('layouts.footer')
